'''

README
------

Steps to how to use perspective logger:

1. On Component action write the following:

	- 	output = str({
            "Message": str(message),
            "Location": str(location),
            "Payload": str(payload)
        })
        
    -	system.perspective.print(output)
	    
2. Change the value as per your need

3. The logs can be seen in the Designer output console OR Browser inspect page

'''
