'''

README
------

Types of logs: info, warn, error

Steps to how to use this logger:

1. On Component action write the following:

	- 	folder_logging99.file_logging_vision.func_loggervis(
	    message="Some message", 
	    location="Mainview/Button1", 
	    payload="dict data", 
	    level="info")
	    
2. Change the value as per your need

3. The logs can be seen in:
	- Designer -> Tools -> Console : if you are testing the actions of the component in the Vision section of the designer
	- Vision Client -> Help -> Diagnostics -> Console : if you are testing the actions of the component in the Vision Client

'''


def func_loggervis(message = "", location = None, payload = None, level = "info"):
    """
    Logs a structured message to the gateway log.

    Args:
        message: Main message to be displayed in the log message.
        location: Location of where this log is triggered.
        payload: Additional details to be displayed in the log message.
    
    Returns:
        Nothing
    """   
    try:
        loggervis = system.util.getLogger("loggervis")
        output = str({
            "Message": str(message),
            "Location": str(location),
            "Payload": str(payload)
        })

        if level.lower() == "warn":
            loggervis.warn(output)
        elif level.lower() == "error":
            loggervis.error(output)
        else:
            loggervis.info(output)
    except Exception as e:
        system.util.getLogger("loggervis").error("Failed to log message: %s" % str(e))