'''

README
------

Types of logs: info, warn, error

Steps to how to use this logger:

1. On Component action write the following:

	- 	folder_logging99.file_logging_gwbk.func_loggergw(
	    message="Some message", 
	    location="Mainview/Button1", 
	    payload="dict data", 
	    level="info")
	    
2. Change the value as per your need

3. The logs can be seen in the browser gateway page -> status -> logs

4. Tags scripts are also shown in the same page but to make it work on the gateway settings 
page add the project name from where the scripts will be used by the tags because tags scope 
is the gateway by default

'''


def func_loggergw(message = "", location = None, payload = None, level = "info"):
    """
    Logs a structured message to the gateway log.

    Args:
        message: Main message to be displayed in the log message.
        location: Location of where this log is triggered.
        payload: Additional details to be displayed in the log message.
    
    Returns:
        Nothing
    """   
    try:
        loggergw = system.util.getLogger("loggergw")
        output = str({
            "Message": str(message),
            "Location": str(location),
            "Payload": str(payload)
        })

        if level.lower() == "warn":
            loggergw.warn(output)
        elif level.lower() == "error":
            loggergw.error(output)
        else:
            loggergw.info(output)
    except Exception as e:
        system.util.getLogger("loggergw").error("Failed to log message: %s" % str(e))