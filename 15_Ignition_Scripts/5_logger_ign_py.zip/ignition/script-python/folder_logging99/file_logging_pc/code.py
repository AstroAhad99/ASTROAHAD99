'''

README
------

Types of logs: info, warning, critical, errors

Steps to how to use this logger:

1. Change the location of the filename where you need to store the logs and create the txt file

2. On Component action write the following:

	- 	loggerpc = folder_logging99.file_logging_pc.var_loggerpc
		
	-	loggerpc.info(
		"Button clicked successfully.",
		extra={
		    'location': 'MainView/Button1',
		    'payload': {'user': 'ahad', 'value': 42}
		})

3. Change the value as per your need

'''


import logging

# Custom basic config including location and payload placeholders
logging.basicConfig(
    format='%(asctime)s ---> %(levelname)-8s [%(filename)s:%(lineno)-5d] ---> Message: %(message)s ---> Location: %(location)s ---> Payload: %(payload)s',
    datefmt='%d-%m-%Y %H:%M:%S',
    level=logging.DEBUG,
    filename='C:\\Users\\Qanare\\Documents\\ASTROAHAD99\\15_Ignition_Scripts\\logging_pc.txt'
)

var_loggerpc = logging.getLogger("Logger_PC")